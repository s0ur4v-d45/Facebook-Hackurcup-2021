package pack1;

public class A {
    public String show()
    {
        return "I am from class A";
    }
}
