package pack1;

public class B {
    public String show()
    {
        return "I am from class B";
    }
}
