import pack1.A;
import pack1.B;

public class Main {
    public static void main(String[] args) {

        A objectOfA = new A();
        System.out.println(objectOfA.show());

        B objectOfB = new B();
        System.out.println(objectOfB.show());

    }
}
